// Listen for keyboard shortcuts
chrome.commands.onCommand.addListener((command) => {
    if (command === "toggle_test") {
        chrome.storage.local.get(['isRunning', 'authToken'], (res) => {
            if (!res.authToken) {
                console.log("Cannot start test: User is not logged in via the extension popup.");
                return;
            }

            const newState = !res.isRunning;
            const updatePayload = { isRunning: newState };
            if (newState) {
                updatePayload.runStartTime = Date.now();
            } else {
                updatePayload.runStartTime = null;
            }
            chrome.storage.local.set(updatePayload);

            // Notify the active tab's content script
            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                if (tabs.length > 0) {
                    if (newState) {
                        // Ensure content script is injected
                        chrome.scripting.executeScript({
                            target: { tabId: tabs[0].id },
                            files: ['content.js']
                        }).then(() => {
                            chrome.tabs.sendMessage(tabs[0].id, { action: "start", token: res.authToken });
                        }).catch(e => console.log("Script injection error:", e));
                    } else {
                        chrome.tabs.sendMessage(tabs[0].id, { action: "stop" });
                    }
                }
            });
        });
    }
});

// Primary global listener for stop events (so we catch stops from popup, content script limits, or keyboard shortcuts)
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (changes.isRunning) {
        if (changes.isRunning.oldValue !== true && changes.isRunning.newValue === true) {
            // Started running
            chrome.storage.local.get(['maxCreditSeconds'], (res) => {
                if (res.maxCreditSeconds && res.maxCreditSeconds > 0) {
                    // Forcefully stop when they visually run out of time
                    chrome.alarms.create("creditExhausted", { delayInMinutes: res.maxCreditSeconds / 60 });
                }
            });
        }
        else if (changes.isRunning.oldValue === true && changes.isRunning.newValue === false) {
            // Stopped running
            chrome.alarms.clear("creditExhausted");
            chrome.storage.local.get(['runStartTime', 'authToken'], (res) => {
                if (res.runStartTime && res.authToken) {
                    let elapsedSeconds = Math.round((Date.now() - res.runStartTime) / 1000);
                    if (elapsedSeconds > 0) {
                        // Cap at max 20 minutes (1200s) to prevent browser-closed massive deductions
                        if (elapsedSeconds > 1200) elapsedSeconds = 1200;

                        console.log(`Sending deduction for ${elapsedSeconds} seconds to server...`);
                        fetch("https://autotestserver.onrender.com/api/deduct_time", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json",
                                "Authorization": `Bearer ${res.authToken}`
                            },
                            body: JSON.stringify({ elapsedSeconds: elapsedSeconds })
                        }).catch(e => console.log("Failed to deduct time:", e));
                    }
                }
            });
        }
    }
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "creditExhausted") {
        console.log("Credits exhausted alarm fired! Forcing stop from background.");
        chrome.storage.local.set({ isRunning: false });
    }
});
