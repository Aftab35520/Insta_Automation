document.addEventListener('DOMContentLoaded', () => {
    let googleLoginBtn = document.getElementById('googleLoginBtn');
    let startBtn = document.getElementById('startBtn');
    let stopBtn = document.getElementById('stopBtn');
    let subscribeBtn = document.getElementById('subscribeBtn');
    let logoutBtn = document.getElementById('logoutBtn');
    let statusDiv = document.getElementById('status');
    let creditsDisplay = document.getElementById('creditsDisplay');
    let userEmail = document.getElementById('userEmail');
    let timerDisplay = document.getElementById('timerDisplay'); // New timer element
    let timerInterval = null;
    let liveCreditSeconds = 0; // The actual time they have globally
    let socket = null; // Hold the websocket connection

    let authToken = localStorage.getItem('realAuthToken');

    function checkIdentity(interactive = false) {
        if (chrome.identity) {
            if (chrome.identity.getProfileUserInfo && !interactive) {
                // Try silent auto-login first
                chrome.identity.getProfileUserInfo({ accountStatus: "ANY" }, function (userInfo) {
                    if (userInfo && userInfo.id && userInfo.email) {
                        setAuth(userInfo.id, userInfo.email);
                    } else {
                        showLoginScreen();
                    }
                });
            } else {
                // Cross-Browser standard OAuth2 Flow (works on Brave, Edge, Firefox, etc)
                const manifest = chrome.runtime.getManifest();
                const clientId = manifest.oauth2.client_id;
                const redirectUri = chrome.identity.getRedirectURL();
                const scopes = manifest.oauth2.scopes.join(' ');

                const authUrl = `https://accounts.google.com/o/oauth2/auth?client_id=${clientId}&response_type=token&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${encodeURIComponent(scopes)}`;

                chrome.identity.launchWebAuthFlow({
                    url: authUrl,
                    interactive: interactive
                }, function (redirectUrl) {
                    if (chrome.runtime.lastError || !redirectUrl) {
                        if (interactive) {
                            alert("Google Login Failed: " + (chrome.runtime.lastError ? chrome.runtime.lastError.message : "User cancelled."));
                        }
                        showLoginScreen();
                        return;
                    }

                    // Extract the token from the redirect URL
                    const urlParams = new URLSearchParams(new URL(redirectUrl).hash.substring(1));
                    const token = urlParams.get('access_token');

                    if (token) {
                        fetch('https://www.googleapis.com/oauth2/v1/userinfo?alt=json', {
                            headers: { Authorization: `Bearer ${token}` }
                        })
                            .then(r => r.json())
                            .then(data => {
                                if (data && data.email) {
                                    setAuth(data.id || btoa(data.email).substring(0, 15), data.email);
                                } else {
                                    if (interactive) alert("Could not fetch email from Google.");
                                    showLoginScreen();
                                }
                            })
                            .catch(err => {
                                console.error(err);
                                if (interactive) alert("Error fetching Google profile.");
                                showLoginScreen();
                            });
                    } else {
                        if (interactive) alert("Failed to extract access token.");
                        showLoginScreen();
                    }
                });
            }
        } else {
            if (interactive) alert("Google Login is completely unsupported in this environment.");
            showLoginScreen();
        }
    }

    function setAuth(uid, email) {
        authToken = `${uid}|${email}`;
        localStorage.setItem('realAuthToken', authToken);
        showAppScreen();
        fetchUserData();
        connectSocket();
    }

    if (authToken) {
        showAppScreen();
        fetchUserData();
        connectSocket();
    } else {
        checkIdentity(false); // Try silent login first
    }

    if (googleLoginBtn) {
        googleLoginBtn.addEventListener('click', () => {
            checkIdentity(true); // Force interactive login attempt
        });
    }

    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            if (socket) socket.disconnect();
            localStorage.removeItem('realAuthToken');
            authToken = null;
            chrome.storage.local.remove(['authToken', 'isRunning']);
            clearInterval(window.creditPolling);
            window.creditPolling = null;
            showLoginScreen();
        });
    }

    function showLoginScreen() {
        document.getElementById('loginSection').style.display = 'block';
        document.getElementById('appSection').style.display = 'none';
    }

    function showAppScreen() {
        document.getElementById('loginSection').style.display = 'none';
        document.getElementById('appSection').style.display = 'block';
    }

    function formatCreditTime(seconds) {
        if (!seconds || seconds <= 0) return "0s";
        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = seconds % 60;
        
        let parts = [];
        if (h > 0) parts.push(`${h}h`);
        if (m > 0 || h > 0) parts.push(`${m}m`);
        parts.push(`${s}s`);
        return parts.join(' ');
    }

    function connectSocket() {
        if (!authToken) return;
        if (socket) socket.disconnect();

        socket = io("https://autotestserver.onrender.com", {
            auth: { token: authToken }
        });

        socket.on("connect", () => console.log("Connected to Realtime Server:", socket.id));
        
        socket.on("update_credits", (data) => {
            // Live updates from server while running
            liveCreditSeconds = data.creditSeconds;
            creditsDisplay.textContent = formatCreditTime(liveCreditSeconds);
            
            if (liveCreditSeconds <= 0) {
                if (stopBtn) stopBtn.click();
            }
        });

        socket.on("out_of_time", () => {
             console.log("Server indicated out of time.");
             liveCreditSeconds = 0;
             creditsDisplay.textContent = formatCreditTime(liveCreditSeconds);
             if (stopBtn) stopBtn.click();
        });
    }

    async function fetchUserData() {
        try {
            console.log("Fetching user data with token:", authToken);
            const res = await fetch("https://autotestserver.onrender.com/api/user", {
                headers: { "Authorization": `Bearer ${authToken}` }
            });

            if (!res.ok) {
                const errText = await res.text();
                console.error("Backend returned error status:", res.status, errText);
                throw new Error(errText);
            }

            const data = await res.json();
            console.log("User data received:", data);

            userEmail.textContent = data.email || "user@example.com";

            liveCreditSeconds = data.creditSeconds || 0;
            creditsDisplay.textContent = formatCreditTime(liveCreditSeconds);

            if (liveCreditSeconds <= 0) {
                subscribeBtn.style.display = 'flex';
                subscribeBtn.textContent = '✨ Top Up 1 Hr (₹30)';
                startBtn.disabled = true;
                startBtn.style.backgroundColor = 'var(--glass-bg)';
                statusDiv.innerHTML = "Out of time. Please top up.";
            } else {
                subscribeBtn.style.display = 'none';
                startBtn.disabled = false;
                startBtn.style.backgroundColor = 'var(--success)';
            }
        } catch (e) {
            console.error("Error fetching user data", e);
            creditsDisplay.textContent = "Error";
            userEmail.textContent = "Connection Failed";
        }
    }

    function updateTimerDisplay(startTime) {
        if (!startTime) {
            if (timerDisplay) timerDisplay.textContent = "00:00";
            return;
        }
        
        const now = Date.now();
        const elapsed = now - startTime;
        const maxTime = 20 * 60 * 1000; // 20 minutes max per run session
        const remaining = Math.max(0, maxTime - elapsed);
        
        if (remaining <= 0) {
            if (timerDisplay) timerDisplay.textContent = "00:00";
            return;
        }

        const minutes = Math.floor(remaining / 60000);
        const seconds = Math.floor((remaining % 60000) / 1000);
        if (timerDisplay) {
            timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }
    }

    function startTimer(startTime) {
        if (timerInterval) clearInterval(timerInterval);
        
        // Ensure user has base credits to even start the visual tick
        if (liveCreditSeconds <= 0) {
            updateTimerDisplay(startTime); // Show it zeros out immediately
            return;
        }

        updateTimerDisplay(startTime);
        timerInterval = setInterval(() => {
            updateTimerDisplay(startTime);
        }, 1000);
    }

    function stopTimer() {
        if (timerInterval) {
            clearInterval(timerInterval);
            timerInterval = null;
        }
        if (timerDisplay) timerDisplay.textContent = "20:00";
    }

    startBtn.addEventListener('click', () => {
        const now = Date.now();
        chrome.storage.local.set({ isRunning: true, authToken: authToken, runStartTime: now, maxCreditSeconds: liveCreditSeconds });
        statusDiv.textContent = "Status: Running...";
        startTimer(now);
        
        if (socket && socket.connected) {
            socket.emit("start_test");
        }

        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                files: ['content.js']
            }).then(() => {
                chrome.tabs.sendMessage(tabs[0].id, { action: "start", token: authToken });
                if (!window.creditPolling) window.creditPolling = setInterval(fetchUserData, 5000);
            });
        });
    });

    stopBtn.addEventListener('click', () => {
        chrome.storage.local.set({ isRunning: false });
        statusDiv.textContent = "Status: Stopped";
        stopTimer();
        clearInterval(window.creditPolling);
        window.creditPolling = null;
        
        if (socket && socket.connected) {
            socket.emit("stop_test");
        }

        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, { action: "stop" });
        });
        
        // Update display to fetch real remainder after deduct finishes
        setTimeout(fetchUserData, 1000);
    });

    subscribeBtn.addEventListener('click', () => {
        const parts = authToken.split('|');
        const email = parts.length > 1 ? parts[1] : '';
        const checkoutUrl = `https://autotestserver.onrender.com/payment.html?token=${encodeURIComponent(authToken)}&email=${encodeURIComponent(email)}`;
        chrome.tabs.create({ url: checkoutUrl });
    });

    chrome.storage.local.get(['isRunning', 'runStartTime'], function (result) {
        if (result.isRunning && authToken) {
            statusDiv.textContent = "Status: Running...";
            if (result.runStartTime) {
                startTimer(result.runStartTime);
            }
            if (!window.creditPolling) window.creditPolling = setInterval(fetchUserData, 5000);
        } else {
             stopTimer();
        }
    });

    // Listen for state changes made by background.js shortcut (Ctrl+Shift+S)
    chrome.storage.onChanged.addListener(function (changes, namespace) {
        if (changes.isRunning) {
            if (changes.isRunning.newValue) {
                statusDiv.textContent = "Status: Running...";
                chrome.storage.local.get(['runStartTime'], function(res) {
                     if (res.runStartTime) startTimer(res.runStartTime);
                });
                if (!window.creditPolling) window.creditPolling = setInterval(fetchUserData, 5000);
            } else {
                statusDiv.textContent = "Status: Stopped";
                stopTimer();
                clearInterval(window.creditPolling);
                window.creditPolling = null;
            }
        }
    });
});
