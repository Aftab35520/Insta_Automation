if (typeof window.aiTesterInitialized === 'undefined') {
    window.aiTesterInitialized = true;

    let isRunning = false;
    let loopTimeout = null;
    let localAuthToken = null; // Store token here when started
    let lastWindowText = null;
    let windowTextSeenTime = 0;
    let runStartTime = 0; // Track max 20 min run time

    // Helper to show a non-intrusive popup instead of alert()
    function showPausePopup(message) {
        let popup = document.getElementById('aftaro-pause-popup');
        if (!popup) {
            popup = document.createElement('div');
            popup.id = 'aftaro-pause-popup';
            popup.style.cssText = `
                position: fixed; top: 20px; right: 20px; z-index: 999999;
                background: #ff4757; color: white; padding: 15px 25px;
                border-radius: 8px; font-family: sans-serif; font-size: 14px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.2); font-weight: bold;
                transition: opacity 0.3s ease;
            `;
            document.body.appendChild(popup);
        }
        popup.textContent = message;
        popup.style.display = 'block';
        popup.style.opacity = '1';

        // Auto hide after 5 seconds
        setTimeout(() => {
            popup.style.opacity = '0';
            setTimeout(() => popup.style.display = 'none', 300);
        }, 5000);
    }

    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === "start") {
            if (!isRunning) {
                isRunning = true;
                localAuthToken = request.token; // Save token from popup/background
                lastWindowText = null;
                windowTextSeenTime = Date.now();
                runStartTime = Date.now();
                console.log(`=== AI Test Assistant Started ===`);
                runTestLoop();
            }
        } else if (request.action === "stop") {
            isRunning = false;
            localAuthToken = null;
            lastWindowText = null;
            if (loopTimeout) clearTimeout(loopTimeout);
            console.log("=== AI Test Assistant Stopped ===");
        }
    });

    // Check if it should immediately start running on a reload/new page based on stored state
    chrome.storage.local.get(['isRunning', 'authToken', 'runStartTime'], function(result) {
        if (result.isRunning && result.authToken) {
            // Restore start time if available, otherwise reset
            runStartTime = result.runStartTime || Date.now();
            
            // If already passed 20 mins, don't restart
            if (Date.now() - runStartTime > 20 * 60 * 1000) {
                chrome.storage.local.set({ isRunning: false });
                return;
            }

            isRunning = true;
            localAuthToken = result.authToken;
            lastWindowText = null;
            windowTextSeenTime = Date.now();
            // Wait a couple seconds after page loads to start
            loopTimeout = setTimeout(runTestLoop, 2000);
        }
    });

    async function runTestLoop() {
        if (!isRunning) return;

        try {
            console.log("\nReading webpage text...");
            const pageText = document.body.innerText;

            console.log("Extracting explicit options (radio/checkbox)...");
            let optionsText = "";
            const radioInputs = document.querySelectorAll("input[type='radio'], input[type='checkbox']");
            
            if (radioInputs.length > 0) {
                optionsText = "Extracted Options:\n";
                radioInputs.forEach(r => {
                    let parentLabel = r.closest('label');
                    if (parentLabel && parentLabel.innerText) {
                        optionsText += `- ${parentLabel.innerText.trim()}\n`;
                    } else if (r.parentElement && r.parentElement.innerText) {
                        optionsText += `- ${r.parentElement.innerText.trim()}\n`;
                    }
                });
            }

            // Constrain runs to exactly 20 minutes max total
            if (Date.now() - runStartTime > 20 * 60 * 1000) {
                console.log("Maximum 20 limit reached. Force closing extension.");
                isRunning = false;
                chrome.storage.local.set({ isRunning: false, runStartTime: null });
                showPausePopup("Aftaro Auto Tester stopped (Max 20 mins limit reached). Click Start to resume.");
                return; // Stop execution
            }

            // Normalize text to ignore running clocks/timers (e.g. 12:34, 1:23:45) which would constantly change the text
            const currentWindowText = (pageText + "\n" + optionsText).replace(/\b\d{1,2}:\d{2}(?::\d{2})?\b/g, '');
            
            if (lastWindowText === currentWindowText) {
                if (Date.now() - windowTextSeenTime > 60000) {
                    console.log("Same window detected for over 1 minute. Force closing extension to prevent API cost waste.");
                    isRunning = false;
                    chrome.storage.local.set({ isRunning: false, runStartTime: null });
                    showPausePopup("Aftaro Auto Tester paused to save credits (no changes detected for 1 minute).");
                    return; // Stop execution
                }
            } else {
                lastWindowText = currentWindowText;
                windowTextSeenTime = Date.now();
            }

            console.log("Asking custom LLM API for the answer...");
            const aiAnswer = await askAi(pageText, optionsText);
            console.log(`AI suggests clicking: '${aiAnswer}'`);

            if (aiAnswer && aiAnswer !== "NONE") {
                const cleanAnswer = aiAnswer.replace(/^[A-Ea-e][\.\)]?\s*\n*/, '').trim();
                console.log(`Cleaned answer string: '${cleanAnswer}'`);

                // Find an element containing this exact string
                const foundElement = findElementByText(cleanAnswer);
                
                if (foundElement) {
                    console.log(`Successfully found an element containing '${cleanAnswer}'. Clicking it...`);
                    foundElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    foundElement.click();
                    
                    // Wait briefly for UI update
                    await new Promise(r => setTimeout(r, 1000));
                    
                    // Try to click Next
                    let nextClicked = await clickNextButton(pageText);
                    
                    if (!nextClicked) {
                        console.log("Could not find a 'Next' button even with AI fallback.");
                    }
                } else {
                    console.log(`Could not find any visible element containing '${cleanAnswer}'. Retrying next loop...`);
                }
            } else {
                console.log("AI did not detect a question. Waiting before retrying...");
            }

        } catch (error) {
            console.error("An error occurred during the test loop:", error);
        }

        // Schedule the next loop if we are still running
        if (isRunning) {
            loopTimeout = setTimeout(runTestLoop, 3000); // Check again every 3 seconds
        }
    }

    async function askAi(pageText, optionsText) {
        const promptText = `You are taking a multiple-choice test. Below is the visible text from the test webpage.
Identify the current question and the options.
Determine the correct answer to the question.
You MUST respond with ONLY the exact text of the correct option as it appears on the page.
DO NOT include the question text in your output under any circumstances.
If there are numbers or letters before the option like "A)" or "1.", include them ONLY if they are part of the option text on the page.
Do not output anything else. No explanations.
If there is no question visible, output 'NONE'.

Webpage Text:
${pageText}

${optionsText}`;

        try {
            console.log(`[Content] Fetching auth token...`);
            // Use the locally stored token (from when the test started)
            const token = localAuthToken;

            if (!token) {
                console.error("[Content] No auth token found, cannot ask AI.");
                return "NONE";
            }

            console.log(`[Content] Sending request to Backend API... (Prompt Size: ${promptText.length})`);
            
            const response = await fetch("https://autotestserver.onrender.com/api/ask", {
                method: "POST",
                headers: { 
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify({ prompt: promptText })
            });
            
            console.log(`[Content] Backend responded with status: ${response.status}`);
            
            if (response.status === 402) {
                console.error("[Content] Out of time! Please top up.");
                isRunning = false; // Stop the loop
                chrome.storage.local.set({ isRunning: false });
                return "OUT_OF_TIME";
            }

            if (!response.ok) {
                const errText = await response.text();
                console.error(`[Content] Backend Error Body: ${errText}`);
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            console.log(`[Content] Answer received: '${data.answer}' | Time remaining: ${data.creditSecondsRemaining}s`);
            return (data.answer || "NONE").trim();
        } catch (e) {
            console.error(`[Content] Error calling backend API:`, e);
            return "NONE";
        }
    }

    function findElementByText(searchText) {
        if (!searchText) return null;
        
        // Convert to lowercase to be safe but exact match preferred
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        let node;
        let candidates = [];
        
        // Gather all text nodes that include the desired string
        while (node = walker.nextNode()) {
            if (node.nodeValue.includes(searchText)) {
                candidates.push(node.parentElement);
            }
        }

        if (candidates.length === 0) return null;

        // Prioritize labels, buttons, or elements that have inputs inside them
        let target = null;
        for (const el of candidates) {
            // Element must be "visible"
            if (el.offsetWidth > 0 && el.offsetHeight > 0) {
                const tag = el.tagName.toLowerCase();
                const hasInput = el.querySelector("input[type=radio], input[type=checkbox]") !== null;
                const isOptionChild = el.closest('label, li, td, .option, .choice') !== null;
                
                if (['label', 'button', 'input'].includes(tag) || hasInput || isOptionChild) {
                    target = el;
                    break;
                }
            }
        }
        
        // Fallback: just return the first visible element that matched
        if (!target) {
            target = candidates.find(el => el.offsetWidth > 0 && el.offsetHeight > 0);
        }
        
        return target;
    }

    async function clickNextButton(pageText) {
        let nextClicked = false;
        
        // 1. Array of possible explicit texts (lowercased for case-insensitive matching)
        const nextTexts = [
            "save & next", "save and next", "submit & next", "next question", "next",
            "nextquestion", "newxq"
        ];
        
        // Find all buttons, links, generalized buttons, AND input buttons
        const interactiveElements = Array.from(document.querySelectorAll("button, a, .btn, .button, [role='button'], input[type='button'], input[type='submit']"));
        
        for (const text of nextTexts) {
            const btn = interactiveElements.find(el => {
                const elText = (el.innerText || el.value || "").trim().toLowerCase();
                return elText === text;
            });
            if (btn && btn.offsetWidth > 0 && btn.offsetHeight > 0) {
                console.log(`Clicking next button found via explicit match: ${text}`);
                btn.scrollIntoView({ behavior: 'smooth', block: 'center' });
                btn.click();
                return true;
            }
        }

        // 2. Fallback to broad partial text matching
        for (const fallback of nextTexts) {
            const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
            let node;
            while (node = walker.nextNode()) {
                if (node.nodeValue.trim().toLowerCase() === fallback) {
                    const el = node.parentElement;
                    if (el && el.offsetWidth > 0 && el.offsetHeight > 0) {
                        console.log(`Clicking fallback generic element with exact text: ${fallback}`);
                        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        el.click();
                        return true;
                    }
                }
            }
        }
        
        // 3. AI Fallback
        console.log("Could not find a 'Next' button via built-in logic. Asking AI...");
        const buttonsText = interactiveElements
            .map(el => "- " + (el.innerText || el.value || "").trim())
            .filter(text => text.length > 2)
            .join("\n");

        const promptText = `You are looking at a multiple-choice test webpage.
Identify the exact text of the button or link that goes to the next question.
You MUST respond with ONLY the exact text of the next button as it appears on the page.
If there are no explicit next buttons, look for 'Submit', 'Save & Next', etc.
Do not output anything else. No explanations.
If there is no next button visible, output 'NONE'.

Webpage Text:
${pageText}

Available Buttons:
${buttonsText}`;

        try {
            const token = localAuthToken;
            if (!token) return false;

            const response = await fetch("https://autotestserver.onrender.com/api/ask", {
                method: "POST",
                headers: { 
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify({ prompt: promptText })
            });

            if (response.status === 402) {
                isRunning = false; 
                chrome.storage.local.set({ isRunning: false });
                console.error("[Content] Out of time! Please top up.");
                return false;
            }
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            const data = await response.json();
            const aiNextBtnText = (data.answer || "NONE").trim();
            
            if (aiNextBtnText !== "NONE") {
                console.log(`AI suggested next button text: '${aiNextBtnText}'`);
                // Try to click it
                const btn = interactiveElements.find(el => {
                    const elText = (el.innerText || el.value || "").trim().toLowerCase();
                    return elText === aiNextBtnText.toLowerCase();
                });
                if (btn && btn.offsetWidth > 0 && btn.offsetHeight > 0) {
                    console.log(`Clicking AI-suggested next button: ${aiNextBtnText}`);
                    btn.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    btn.click();
                    return true;
                }
                
                // Try exact match with text walker for AI response as well
                const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
                let node;
                while (node = walker.nextNode()) {
                    if (node.nodeValue.trim().toLowerCase() === aiNextBtnText.toLowerCase()) {
                        const el = node.parentElement;
                        if (el && el.offsetWidth > 0 && el.offsetHeight > 0) {
                            console.log(`Clicking AI fallback generic element with exact text: ${aiNextBtnText}`);
                            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                            el.click();
                            return true;
                        }
                    }
                }
            } else {
                console.log("AI did not find a 'Next' button.");
            }
        } catch (e) {
            console.error(`[Content] Error calling backend API for next button:`, e);
        }

        return false;
    }
}
